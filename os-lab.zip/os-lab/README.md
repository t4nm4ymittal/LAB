# Operating Systems Lab
Codes pertaining to OS Lab for Course CO254 - Operating Systems Lab

## Bonus

If you like this repo, you'd probably like [Operating Systems Simulator](https://github.com/mishal23/os-simulator) too -- it's visualization of most of the common Operating Systems concepts.

Website: http://uos-simulator.herokuapp.com/
